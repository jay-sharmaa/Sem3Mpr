package com.example.shoppinapp;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

public class ProfileFragment extends Fragment {
    public ProfileFragment() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_profile, container, false);
        TextView tvusername,tvpassword,tvphone,tvemail,tvaddress,tvcountry;
        Button butmyorders,butmycart,buthelpcentre;
        tvusername=view.findViewById(R.id.tvusername);
        tvpassword=view.findViewById(R.id.tvpassword);
        tvphone=view.findViewById(R.id.tvphone);
        tvemail=view.findViewById(R.id.tvemail);
        tvaddress=view.findViewById(R.id.tvaddress);
        tvcountry=view.findViewById(R.id.tvcountry);
        butmyorders=view.findViewById(R.id.butmyorders);
        butmycart=view.findViewById(R.id.butmycart);
        buthelpcentre=view.findViewById(R.id.buthelpcentre);
        //login l=new login();
        tvusername.setText(login.str[0]);
        tvpassword.setText(login.str[1]);
        tvemail.setText(login.str[2]);
        tvemail.setText(Register.giveemail());
        tvphone.setVisibility(View.GONE);
        tvemail.setVisibility(View.GONE);
        tvaddress.setVisibility(View.GONE);
        tvcountry.setVisibility(View.GONE);
        return view;
    }
}