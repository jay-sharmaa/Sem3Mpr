package com.example.shoppinapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class All_Item_Activity extends AppCompatActivity {
    ImageView firstimage,secondimage,thirdimage;
    TextView brandname,itemname,price;
    Button butorder,butadd;
    static  int d = -1;
    static int item_id = 0,num = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_all_item);
        firstimage = findViewById(R.id.firstimage);
        secondimage = findViewById(R.id.secondimage);
        thirdimage = findViewById(R.id.thirdimage);
        brandname = findViewById(R.id.selectedbrand);
        itemname = findViewById(R.id.selecteditem);
        price = findViewById(R.id.price);
        butorder = findViewById(R.id.butorder);
        butadd=findViewById(R.id.butadd);
        Intent intent = getIntent();
        item_id = intent.getIntExtra("Key",-1);
         {
            if (item_id == 0) {
                firstimage.setImageResource(R.drawable.item_realme_1);
                secondimage.setImageResource(R.drawable.item_realme_2);
                thirdimage.setImageResource(R.drawable.item_realme_3);
                brandname.setText("Realme");
                itemname.setText("Realme Narzo 10");
                price.setText("15000/-");
            } else if (item_id == 1) {
                firstimage.setImageResource(R.drawable.ball1);
                secondimage.setImageResource(R.drawable.ball2);
                thirdimage.setImageResource(R.drawable.ball3);
                brandname.setText("Ballz");
                itemname.setText("Tennis Balls");
                price.setText("250/-");
            } else if (item_id == 2) {
                firstimage.setImageResource(R.drawable.shoes1);
                secondimage.setImageResource(R.drawable.shoes2);
                thirdimage.setImageResource(R.drawable.shoes3);
                brandname.setText("Reebok");
                itemname.setText("Reebok Nitro 1");
                price.setText("899/-");
            } else if (item_id == 3) {
                firstimage.setImageResource(R.drawable.tshirt1);
                secondimage.setImageResource(R.drawable.tshirt2);
                thirdimage.setImageResource(R.drawable.tshirt3);
                brandname.setText("Jack n Jones");
                itemname.setText("Flexible T-shirt");
                price.setText("459/-");
            } else if (item_id == 4) {
                firstimage.setImageResource(R.drawable.laptop1);
                secondimage.setImageResource(R.drawable.laptop2);
                thirdimage.setImageResource(R.drawable.laptop3);
                brandname.setText("Asus");
                itemname.setText("Asus Tuf Dash F-15");
                price.setText("69999/-");
            } else if (item_id == 5) {
                firstimage.setImageResource(R.drawable.cricket1);
                secondimage.setImageResource(R.drawable.cricket2);
                thirdimage.setImageResource(R.drawable.cricket3);
                brandname.setText("Kakabura");
                itemname.setText("Hit Hard 7");
                price.setText("1699/-");
            } else if (item_id == 6) {
                firstimage.setImageResource(R.drawable.womenshoes1);
                secondimage.setImageResource(R.drawable.womenshoes2);
                thirdimage.setImageResource(R.drawable.womenshoes3);
                brandname.setText("Slim Wear");
                itemname.setText("Slim wear extra-soft");
                price.setText("399/-");
            } else if (item_id == 7) {
                firstimage.setImageResource(R.drawable.pant1);
                secondimage.setImageResource(R.drawable.pant2);
                thirdimage.setImageResource(R.drawable.pant3);
                brandname.setText("Ben Martin");
                itemname.setText("Full Length Best Quality");
                price.setText("799/-");
            }
        }
        butadd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                d = item_id;
                num += 1;
            }
        });
        butorder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
             Intent i=new Intent(All_Item_Activity.this,com.example.shoppinapp.order.class);
             startActivity(i);
         }
        });
    }
}