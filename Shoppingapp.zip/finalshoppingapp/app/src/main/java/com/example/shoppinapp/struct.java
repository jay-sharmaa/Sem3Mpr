package com.example.shoppinapp;

public class struct {
    int id;
    String Username,Password,Email;
}
