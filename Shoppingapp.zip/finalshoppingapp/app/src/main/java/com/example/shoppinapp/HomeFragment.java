package com.example.shoppinapp;

import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class HomeFragment extends Fragment implements Itemclicklistener{

    private List<Itemmodel> itemmodels;
    private CustomHomeAdapter homeAdapter;
    public HomeFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        View view =  inflater.inflate(R.layout.fragment_home, container, false);
        RecyclerView recyclerView = (RecyclerView) view.findViewById(R.id.recycleview);
        itemmodels = new ArrayList<>();
        Itemmodel i1 = new Itemmodel(R.drawable.item_realme_1,"Realme","Realme Narzo 10","15,000/-");
        Itemmodel i2 = new Itemmodel(R.drawable.ball1,"Ballz","Tennis Balls","250/-");
        Itemmodel i3 = new Itemmodel(R.drawable.shoes1,"Reebok","Reebok Nitro 1","899/-");
        Itemmodel i4 = new Itemmodel(R.drawable.tshirt1,"Jack n Jones","Flexible T-shirt","459/-");
        Itemmodel i5 = new Itemmodel(R.drawable.laptop1,"Asus","Asus Tuf Dash F-15","69,999/-");
        Itemmodel i6 = new Itemmodel(R.drawable.cricket1,"Kakabura","Hit hard X7","1699/-");
        Itemmodel i7 = new Itemmodel(R.drawable.womenshoes1,"Slim Wear","Slim wear extra-soft","399/-");
        Itemmodel i8 = new Itemmodel(R.drawable.pant1,"Ben Martin","Full length Best Quality","799/-");
        //
        itemmodels.add(i1);
        itemmodels.add(i2);
        itemmodels.add(i3);
        itemmodels.add(i4);
        itemmodels.add(i5);
        itemmodels.add(i6);
        itemmodels.add(i7);
        itemmodels.add(i8);

        //
        homeAdapter = new CustomHomeAdapter(itemmodels);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        recyclerView.setAdapter(homeAdapter);
        homeAdapter.setItemclicklistener(this);
        //
        return view;
    }
//    @Override
    public void onCllick(View view, int pos) {
        Intent intent = new Intent(getContext(),All_Item_Activity.class);
        intent.putExtra("Key",pos);
        startActivity(intent);
    }
}