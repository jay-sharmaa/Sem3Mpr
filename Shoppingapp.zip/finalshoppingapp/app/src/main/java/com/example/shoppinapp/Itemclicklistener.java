package com.example.shoppinapp;

import android.view.View;

public interface Itemclicklistener {
    public void onCllick(View view, int pos);
}
