package com.example.shoppinapp;

import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class CategoryFragment extends Fragment {

    public CategoryFragment() {
    }
    ImageView imgclothes,imgelectronics,imgsports,imgshoes;

    private CustomHomeAdapter categoryadapter;

    private ArrayList<Itemmodel> list;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_category, container, false);

        imgelectronics=view.findViewById(R.id.imgelectronics);
        imgsports=view.findViewById(R.id.imgsports);
        imgshoes=view.findViewById(R.id.imgshoes);
        imgclothes=view.findViewById(R.id.imgclothes);
        
        list = new ArrayList<>();

        Itemmodel i1 = new Itemmodel(R.drawable.item_realme_1,"Realme","Realme Narzo 10","15,000/-");
        Itemmodel i2 = new Itemmodel(R.drawable.ball1,"Ballz","Tennis Balls","250/-");
        Itemmodel i3 = new Itemmodel(R.drawable.shoes1,"Reebok","Reebok Nitro 1","899/-");
        Itemmodel i4 = new Itemmodel(R.drawable.tshirt1,"Jack n Jones","Flexible T-shirt","459/-");
        Itemmodel i5 = new Itemmodel(R.drawable.laptop1,"Asus","Asus Tuf Dash F-15","69,999/-");
        Itemmodel i6 = new Itemmodel(R.drawable.cricket1,"Kakabura","Hit hard X7","1699/-");
        Itemmodel i7 = new Itemmodel(R.drawable.womenshoes1,"Slim Wear","Slim wear extra-soft","399/-");
        Itemmodel i8 = new Itemmodel(R.drawable.pant1,"Ben Martin","Full length Best Quality","799/-");

        imgclothes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getContext(), categoryview.class);
                intent.putExtra("revdata",1);
                startActivity(intent);
            }
        });

        imgshoes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getContext(), categoryview.class);
                intent.putExtra("revdata",2);
                startActivity(intent);
            }
        });

        imgsports.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getContext(), categoryview.class);
                intent.putExtra("revdata",3);
                startActivity(intent);
            }
        });

        imgelectronics.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getContext(), categoryview.class);
                intent.putExtra("revdata",4);
                startActivity(intent);
            }
        });
        return view;
    }
}