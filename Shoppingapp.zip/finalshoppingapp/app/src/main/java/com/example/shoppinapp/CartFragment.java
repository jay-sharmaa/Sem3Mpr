package com.example.shoppinapp;

import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class CartFragment extends Fragment implements Itemclicklistener{
    public CartFragment() {
        // Required empty public constructor
    }

    private List<Itemmodel> itemmodels;
    private CustomHomeAdapter customHomeAdapter;
    int pos = All_Item_Activity.d;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_cart, container, false);
        RecyclerView recyclerView = (RecyclerView) view.findViewById(R.id.recycleview);
        itemmodels = new ArrayList<>();
        Itemmodel i1 = new Itemmodel(R.drawable.item_realme_1,"Realme","Realme Narzo 10","15,000/-");
        Itemmodel i2 = new Itemmodel(R.drawable.ball1,"Ballz","Tennis Balls","250/-");
        Itemmodel i3 = new Itemmodel(R.drawable.shoes1,"Reebok","Reebok Nitro 1","899/-");
        Itemmodel i4 = new Itemmodel(R.drawable.tshirt1,"Jack n Jones","Flexible T-shirt","459/-");
        Itemmodel i5 = new Itemmodel(R.drawable.laptop1,"Asus","Asus Tuf Dash F-15","69,999/-");
        Itemmodel i6 = new Itemmodel(R.drawable.cricket1,"Kakabura","Hit hard X7","1699/-");
        Itemmodel i7 = new Itemmodel(R.drawable.womenshoes1,"Slim Wear","Slim wear extra-soft","399/-");
        Itemmodel i8 = new Itemmodel(R.drawable.pant1,"Ben Martin","Full length Best Quality","799/-");
            if(pos == -1){

            }
            else if (pos == 0) {
                itemmodels.add(i1);
            } else if (pos == 1) {
                itemmodels.add(i2);
            } else if (pos == 2) {
                itemmodels.add(i3);
            } else if (pos == 3) {
                itemmodels.add(i4);
            } else if (pos == 4) {
                itemmodels.add(i5);
            } else if (pos == 5) {
                itemmodels.add(i6);
            } else if (pos == 6) {
                itemmodels.add(i7);
            } else {
                itemmodels.add(i8);
            }
        customHomeAdapter = new CustomHomeAdapter(itemmodels);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        recyclerView.setAdapter(customHomeAdapter);
        customHomeAdapter.setItemclicklistener(this);
        return view;
    }
    public void onCllick(View view, int pos) {
        pos = All_Item_Activity.d;
        Intent intent = new Intent(getContext(),All_Item_Activity.class);
        intent.putExtra("Key",pos);
        startActivity(intent);
    }
}