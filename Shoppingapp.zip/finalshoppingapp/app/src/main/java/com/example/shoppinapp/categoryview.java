package com.example.shoppinapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import java.util.ArrayList;
import java.util.List;

public class categoryview extends AppCompatActivity implements Itemclicklistener{

    private List<Itemmodel> itemmodels;
    private CustomHomeAdapter homeAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_categoryview);
        Intent intent = getIntent();
        int senddata = intent.getIntExtra("revdata",0);

        RecyclerView recyclerView = (RecyclerView) findViewById(R.id.recycleviewcategory);
        itemmodels = new ArrayList<>();
        Itemmodel i1 = new Itemmodel(R.drawable.item_realme_1,"Realme","Realme Narzo 10","15,000/-");
        Itemmodel i2 = new Itemmodel(R.drawable.ball1,"Ballz","Tennis Balls","250/-");
        Itemmodel i3 = new Itemmodel(R.drawable.shoes1,"Reebok","Reebok Nitro 1","899/-");
        Itemmodel i4 = new Itemmodel(R.drawable.tshirt1,"Jack n Jones","Flexible T-shirt","459/-");
        Itemmodel i5 = new Itemmodel(R.drawable.laptop1,"Asus","Asus Tuf Dash F-15","69,999/-");
        Itemmodel i6 = new Itemmodel(R.drawable.cricket1,"Kakabura","Hit hard X7","1699/-");
        Itemmodel i7 = new Itemmodel(R.drawable.womenshoes1,"Slim Wear","Slim wear extra-soft","399/-");
        Itemmodel i8 = new Itemmodel(R.drawable.pant1,"Ben Martin","Full length Best Quality","799/-");

        homeAdapter = new CustomHomeAdapter(itemmodels);
        recyclerView.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
        recyclerView.setAdapter(homeAdapter);
        homeAdapter.setItemclicklistener(this);

        if(senddata == 1){
            itemmodels.add(i4);
            itemmodels.add(i7);
            itemmodels.add(i8);
        } else if (senddata == 2) {
            itemmodels.add(i3);
        } else if (senddata == 3) {
            itemmodels.add(i2);
            itemmodels.add(i6);
        } else if (senddata == 4) {
            itemmodels.add(i1);
            itemmodels.add(i5);
        }
    }
    @Override
    public void onCllick(View view, int pos) {
        pos = All_Item_Activity.d;
        Intent intent = new Intent(getApplicationContext(),All_Item_Activity.class);
        intent.putExtra("Key",pos);
        startActivity(intent);
    }
}