package com.example.shoppinapp;

import androidx.activity.OnBackPressedDispatcher;
import androidx.activity.OnBackPressedDispatcherOwner;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;
import android.sax.RootElement;
import android.view.MenuItem;

import com.google.android.material.badge.BadgeDrawable;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;

public class MainActivity extends AppCompatActivity {
    BottomNavigationView bottomNavigationView;
    int main_id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        bottomNavigationView = findViewById(R.id.bottom_navigation);
        loadfragment(new HomeFragment(),true);
        BadgeDrawable badgeDrawable = bottomNavigationView.getOrCreateBadge(R.id.nav_cart);
        bottomNavigationView.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int id = item.getItemId();
                main_id = id;
                if(id == R.id.nav_home){
                    loadfragment(new HomeFragment(),false);
                }
                else if(id == R.id.nav_profile){
                    loadfragment(new ProfileFragment(),false);
                }
                else if(id == R.id.nav_cart){
                    loadfragment(new CartFragment(),false);
                }
                else{
                    loadfragment(new CategoryFragment(),false);
                }
                badgeDrawable.setVisible(true);
                badgeDrawable.setNumber(All_Item_Activity.num);
                return true;
            }
        });
    }
    public void loadfragment(Fragment fragment, boolean flag){
        FragmentManager fm = getSupportFragmentManager();
        FragmentTransaction ft = fm.beginTransaction();
        if(flag){
            ft.add(R.id.container,fragment);
        }
        else{
            ft.replace(R.id.container,fragment);
        }
        ft.commit();
    }
    @Override
    public void onBackPressed() {
        if(main_id != R.id.nav_home){
            loadfragment(new HomeFragment(),false);
            main_id = R.id.nav_home;
        }
        else
            super.onBackPressed();
    }
}